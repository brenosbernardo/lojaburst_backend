﻿namespace lojaburst.Models
{
    public class LoginModel
    {
    }
}
